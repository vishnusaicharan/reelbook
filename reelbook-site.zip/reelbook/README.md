# Reelwala – iPhone content creator booking site

1. Install Node.js 18 or newer from nodejs.org.
2. In this folder run:  npm install
3. Set your admin login and secret, then start:
   Mac/Linux:  JWT_SECRET=long-random-text ADMIN_EMAIL=you@example.com ADMIN_PASSWORD=strong-pass npm start
   Windows:    set JWT_SECRET=long-random-text && set ADMIN_EMAIL=you@example.com && set ADMIN_PASSWORD=strong-pass && npm start
4. Open http://localhost:3000 and log in with your admin email and password. The Admin section appears at the bottom of the page.

Data (users, bookings, reels, uploaded videos) lives in the data/ folder. Back it up regularly.

Hosting: use any host that runs Node and keeps a persistent disk (Railway, Render with a disk, a VPS). Set NODE_ENV=production behind HTTPS.
