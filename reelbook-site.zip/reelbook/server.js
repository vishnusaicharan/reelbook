const express=require('express'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken'),multer=require('multer'),cookies=require('cookie-parser');
const PORT=process.env.PORT||3000,SECRET=process.env.JWT_SECRET||'change-me-now',PROD=process.env.NODE_ENV==='production';
const DIR=path.join(__dirname,'data'),DB=path.join(DIR,'db.json'),UP=path.join(DIR,'uploads');
fs.mkdirSync(UP,{recursive:true});
const uid=()=>crypto.randomBytes(6).toString('hex'),rd=(b,m)=>Math.round(b*m/50)*50;
const mk=(id,n,b)=>({id,n,p:{quick:b,std:rd(b,2.4),full:rd(b,4.5)}});
let db=fs.existsSync(DB)?JSON.parse(fs.readFileSync(DB)):{users:[],bookings:[],reels:[],wa:'',
 pay:{upi:'',name:'',bank:'',acc:'',ifsc:'',qr:''},
 cats:[mk('car','Car delivery',2499),mk('bike','Bike delivery',1999),mk('house','House warming',2999),mk('event','Events',3999),mk('brand','Brand reels',2499)]};
const save=()=>fs.writeFileSync(DB,JSON.stringify(db,null,1));
if(!db.users.some(u=>u.role==='admin')){db.users.push({id:uid(),name:'Admin',email:(process.env.ADMIN_EMAIL||'admin@example.com').toLowerCase(),phone:'',hash:bcrypt.hashSync(process.env.ADMIN_PASSWORD||'admin12345',10),role:'admin'});save()}
const up=multer({storage:multer.diskStorage({destination:UP,filename:(q,f,cb)=>cb(null,uid()+path.extname(f.originalname).toLowerCase().replace(/[^.a-z0-9]/g,''))}),limits:{fileSize:80*1024*1024},
 fileFilter:(q,f,cb)=>cb(null,/^(video|image)\//.test(f.mimetype))});
const app=express();app.use(express.json({limit:'1mb'}),cookies());
app.use('/uploads',express.static(UP));app.use(express.static(path.join(__dirname,'public')));
const wrap=f=>(q,s)=>{try{f(q,s)}catch(e){s.status(400).json({error:e.message})}};
const pub=u=>u&&{id:u.id,name:u.name,email:u.email,phone:u.phone,role:u.role};
function who(q){try{return db.users.find(u=>u.id===jwt.verify(q.cookies.t,SECRET).id)}catch{}}
const auth=(q,s,n)=>{q.u=who(q);q.u?n():s.status(401).json({error:'Please log in first'})};
const admin=(q,s,n)=>auth(q,s,()=>q.u.role==='admin'?n():s.status(403).json({error:'Admins only'}));
const login=(s,u)=>{s.cookie('t',jwt.sign({id:u.id},SECRET,{expiresIn:'30d'}),{httpOnly:true,sameSite:'lax',secure:PROD,maxAge:30*864e5});s.json({user:pub(u)})};
const clean=(v,n=200)=>String(v||'').trim().slice(0,n);

app.get('/api/site',(q,s)=>s.json({cats:db.cats,pay:db.pay,reels:db.reels}));
app.get('/api/me',(q,s)=>s.json({user:pub(who(q))||null}));
app.post('/api/signup',wrap((q,s)=>{const {name,email,phone,password}=q.body,e=clean(email).toLowerCase();
 if(!clean(name)||!/^\S+@\S+\.\S+$/.test(e))throw Error('Enter your name and a valid email');
 if(!/^[6-9]\d{9}$/.test(clean(phone).replace(/\D/g,'').slice(-10)))throw Error('Enter a valid 10-digit mobile number');
 if(String(password||'').length<8)throw Error('Password must be at least 8 characters');
 if(db.users.some(u=>u.email===e))throw Error('That email is already registered');
 const u={id:uid(),name:clean(name,80),email:e,phone:clean(phone,15),hash:bcrypt.hashSync(password,10),role:'customer'};db.users.push(u);save();login(s,u)}));
app.post('/api/login',wrap((q,s)=>{const u=db.users.find(x=>x.email===clean(q.body.email).toLowerCase());
 if(!u||!bcrypt.compareSync(String(q.body.password||''),u.hash))throw Error('Wrong email or password');login(s,u)}));
app.post('/api/logout',(q,s)=>{s.clearCookie('t');s.json({ok:true})});

app.post('/api/bookings',auth,wrap((q,s)=>{const b=q.body,c=db.cats.find(x=>x.id===b.cat);
 if(!c||!c.p[b.pkg])throw Error('Choose an occasion and package');
 if(!clean(b.date)||!clean(b.loc))throw Error('Date and location are required');
 if(!/^[A-Za-z0-9]{6,30}$/.test(clean(b.utr)))throw Error('Enter the payment reference (UTR)');
 const r={id:'RW'+uid().slice(0,5).toUpperCase(),uid:q.u.id,cat:b.cat,pkg:b.pkg,amt:c.p[b.pkg],date:clean(b.date,20),time:clean(b.time,10),loc:clean(b.loc),notes:clean(b.notes,500),utr:clean(b.utr,30),status:'pending',at:new Date().toISOString()};
 db.bookings.unshift(r);save();s.json(r)}));
app.get('/api/bookings',auth,(q,s)=>{const a=q.u.role==='admin';
 s.json(db.bookings.filter(b=>a||b.uid===q.u.id).map(b=>{const u=db.users.find(x=>x.id===b.uid)||{};return a?{...b,name:u.name,phone:u.phone,email:u.email}:b}))});

app.put('/api/admin/settings',admin,wrap((q,s)=>{const {cats,pay,wa}=q.body;
 db.cats.forEach(c=>{const n=(cats||[]).find(x=>x.id===c.id);if(n)for(const k of ['quick','std','full'])c.p[k]=Math.max(0,Number(n.p[k])||0)});
 for(const k of ['upi','name','bank','acc','ifsc'])db.pay[k]=clean((pay||{})[k],80);db.wa=clean(wa,15);save();s.json({ok:true})}));
app.post('/api/admin/qr',admin,up.single('file'),wrap((q,s)=>{if(!q.file)throw Error('Upload an image');db.pay.qr='/uploads/'+q.file.filename;save();s.json({qr:db.pay.qr})}));
app.post('/api/admin/reels',admin,up.single('video'),wrap((q,s)=>{if(!q.file||!q.file.mimetype.startsWith('video/'))throw Error('Upload a video file');
 const r={id:uid(),t:clean(q.body.title,80)||'Untitled reel',c:db.cats.some(c=>c.id===q.body.cat)?q.body.cat:db.cats[0].id,src:'/uploads/'+q.file.filename};db.reels.unshift(r);save();s.json(r)}));
app.delete('/api/admin/reels/:id',admin,(q,s)=>{const r=db.reels.find(x=>x.id===q.params.id);
 if(r){fs.unlink(path.join(UP,path.basename(r.src)),()=>{});db.reels=db.reels.filter(x=>x!==r);save()}s.json({ok:true})});
app.patch('/api/admin/bookings/:id',admin,wrap((q,s)=>{const b=db.bookings.find(x=>x.id===q.params.id);
 if(!b||!['pending','confirmed','cancelled'].includes(q.body.status))throw Error('Invalid');b.status=q.body.status;save();s.json(b)}));
app.listen(PORT,()=>console.log('Running on http://localhost:'+PORT));
